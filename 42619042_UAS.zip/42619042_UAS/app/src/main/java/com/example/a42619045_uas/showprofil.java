package com.example.a42619045_uas;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import androidx.annotation.Nullable;

public class showprofil extends AppCompatActivity  {
    ImageView imageView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_notifications);

        TextView textView = findViewById(R.id.shownama);
        TextView textView1 = findViewById(R.id.showemail);
        imageView = findViewById(R.id.img1);

    }
}
